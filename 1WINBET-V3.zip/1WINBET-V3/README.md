# 1WINBET V3 Demo

Responsive sportsbook + casino front-end prototype for GitHub Pages.

## Included
- Home page
- Sportsbook with live-style matches and multiple simulated markets
- Multi-selection demo bet slip
- Casino lobby and simulated slot machine
- Account/history page
- LocalStorage virtual balance
- Responsive design

## Important
Virtual credits only. No real-money deposits, withdrawals, payment processing, cash wagering, or settlement are included.

## GitHub Pages structure
Keep these paths exactly:

index.html
sportsbook.html
casino.html
account.html
css/style.css
js/app.js
js/sportsbook.js
js/casino.js
